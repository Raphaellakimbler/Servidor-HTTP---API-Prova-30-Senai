const http = require('http');

const lanches = [
  { id: 1, nome: 'X-Burguer', preco: 18 },
  { id: 2, nome: 'X-Salada', preco: 19 },
  { id: 3, nome: 'X-Duplo', preco: 25 }
];

const server = http.createServer((req, res) => {
  res.setHeader('Content-Type', 'application/json');

  if (req.method === 'GET' && req.url === '/') {
    res.writeHead(200);
    res.end(JSON.stringify({ api: 'Cardápio da Lanchonete', versao: '1.0' }));

  } else if (req.method === 'GET' && req.url === '/lanches') {
    res.writeHead(200);
    res.end(JSON.stringify(lanches));

  } else if (req.method === 'GET' && req.url === '/lanches/destaques') {
    const destaques = [];

    for (let i = 0; i < lanches.length; i++) {
      if (lanches[i].preco < 20) {
        destaques.push(lanches[i]);
      }
    }

    res.writeHead(200);
    res.end(JSON.stringify(destaques));

  } else if (req.method === 'GET' && req.url.startsWith('/lanches/')) {
    const id = parseInt(req.url.split('/')[2]);
    let encontrado = null;

    for (let i = 0; i < lanches.length; i++) {
      if (lanches[i].id === id) {
        encontrado = lanches[i];
      }
    }

    if (encontrado) {
      res.writeHead(200);
      res.end(JSON.stringify(encontrado));
    } else {
      res.writeHead(404);
      res.end(JSON.stringify({ erro: 'Lanche não encontrado' }));
    }

  } else {
    res.writeHead(404);
    res.end(JSON.stringify({ erro: 'não encontrada' }));
  }
});

server.listen(3003, () => {
  console.log('Servidor rodando em http://localhost:3003');
});
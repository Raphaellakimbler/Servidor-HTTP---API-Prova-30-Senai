const http = require('http');
const filmeRoutes = require('./routes/filmeRoutes');

const server = http.createServer((req, res) => {
  res.setHeader('Content-Type', 'application/json');

  if (req.url.startsWith('/filmes')) {
    filmeRoutes(req, res);
  } else {
    res.writeHead(404);
    res.end(JSON.stringify({ erro: 'rot a não encontrada' }));
  }
});

server.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');
});  
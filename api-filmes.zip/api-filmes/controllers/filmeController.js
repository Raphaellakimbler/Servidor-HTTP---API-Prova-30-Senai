
const filmes = [
    { id: 1, titulo: 'Inception', genero: 'Ficção', nota: 9 },
    { id: 2, titulo: 'Interstellar', genero: 'Ficção', nota: 9 },
    { id: 3, titulo: 'Procurando Nemo', genero: 'Animação', nota: 8 }
   ];
   
   let proximoId = 4;
   
   function listarTodos(req, res) {
    res.writeHead(200);
    res.end(JSON.stringify(filmes));
   }
   
   function listarDestaques(req, res) {
    const destaques = [];
   
    for (let i = 0; i < filmes.length; i++) {
      if (filmes[i].nota >= 8) {
        destaques.push(filmes[i]);
      }
    }
   
    res.writeHead(200);
    res.end(JSON.stringify(destaques));
   }
   
   function buscarPorId(req, res, id) {
    let encontrado = null;
   
    for (let i = 0; i < filmes.length; i++) {
      if (filmes[i].id === id) {
        encontrado = filmes[i];
      }
    }
   
    if (encontrado) {
      res.writeHead(200);
      res.end(JSON.stringify(encontrado));
    } else {
      res.writeHead(404);
      res.end(JSON.stringify({ erro: 'Filme não encontrado' }));
    }
   }
   
   function criar(req, res) {
    let body = '';
   
    req.on('data', (chunk) => {
      body += chunk;
    });
   
    req.on('end', () => {
      const dados = JSON.parse(body);
   
      if (!dados.titulo || dados.titulo === '') {
        res.writeHead(400);
        res.end(JSON.stringify({ erro: 'Campo titulo é obrigatório' }));
        return;
      }
   
      if (!dados.genero || dados.genero === '') {
        res.writeHead(400);
        res.end(JSON.stringify({ erro: 'Campo genero é obrigatório' }));
        return;
      }
   
      if (dados.nota === undefined || dados.nota === null || dados.nota < 0 || dados.nota > 10) {
        res.writeHead(400);
        res.end(JSON.stringify({ erro: 'Campo nota é obrigatório e deve ser entre 0 e 10' }));
        return;
      }
   
      const novoFilme = {
        id: proximoId,
        titulo: dados.titulo,
        genero: dados.genero,
        nota: dados.nota
      };
   
      proximoId++;
      filmes.push(novoFilme);
   
      res.writeHead(201);
      res.end(JSON.stringify(novoFilme));
    });
   }
   
   function atualizar(req, res, id) {
    let encontrado = null;
   
    for (let i = 0; i < filmes.length; i++) {
      if (filmes[i].id === id) {
        encontrado = filmes[i];
      }
    }
   
    if (!encontrado) {
      res.writeHead(404);
      res.end(JSON.stringify({ erro: 'Filme não encontrado' }));
      return;
    }
   
    let body = '';
   
    req.on('data', (chunk) => {
      body += chunk;
    });
   
    req.on('end', () => {
      const dados = JSON.parse(body);
   
      if (dados.titulo !== undefined) encontrado.titulo = dados.titulo;
      if (dados.genero !== undefined) encontrado.genero = dados.genero;
      if (dados.nota !== undefined) encontrado.nota = dados.nota;
   
      res.writeHead(200);
      res.end(JSON.stringify(encontrado));
    });
   }
   
   function remover(req, res, id) {
    let index = -1;
   
    for (let i = 0; i < filmes.length; i++) {
      if (filmes[i].id === id) {
        index = i;
      }
    }
   
    if (index === -1) {
      res.writeHead(404);
      res.end(JSON.stringify({ erro: 'Filme não encontrado' }));
      return;
    }
   
    filmes.splice(index, 1);
    res.writeHead(204);
    res.end();
   }
   
   function substituir(req, res, id) {
    let index = -1;
   
    for (let i = 0; i < filmes.length; i++) {
      if (filmes[i].id === id) {
        index = i;
      }
    }
   
    if (index === -1) {
      res.writeHead(404);
      res.end(JSON.stringify({ erro: 'Filme não encontrado' }));
      return;
    }
   
    let body = '';
   
    req.on('data', (chunk) => {
      body += chunk;
    });
   
    req.on('end', () => {
      const dados = JSON.parse(body);
   
      if (!dados.titulo || !dados.genero || dados.nota === undefined) {
        res.writeHead(400);
        res.end(JSON.stringify({ erro: 'Campos titulo, genero e nota são obrigatórios' }));
        return;
      }
   
      const filmeSubstituido = {
        id: id,
        titulo: dados.titulo,
        genero: dados.genero,
        nota: dados.nota
      };
   
      filmes[index] = filmeSubstituido;
   
      res.writeHead(200);
      res.end(JSON.stringify(filmeSubstituido));
    });
   }
   
   module.exports = { listarTodos, listarDestaques, buscarPorId, criar, atualizar, remover, substituir };
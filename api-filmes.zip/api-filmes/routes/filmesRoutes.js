const controller = require('../controllers/filmeController');

function filmeRoutes(req, res) {
  const partes = req.url.split('/');
  const id = parseInt(partes[2]);

  if (req.method === 'GET' && req.url === '/filmes') {
    controller.listarTodos(req, res);

  } else if (req.method === 'GET' && partes[1] === 'filmes' && partes[2]) {
    controller.buscarPorId(req, res, id);

  } else if (req.method === 'POST' && req.url === '/filmes') {
    controller.criar(req, res);

  } else if (req.method === 'PATCH' && partes[1] === 'filmes' && partes[2]) {
    controller.atualizar(req, res, id);

  } else if (req.method === 'DELETE' && partes[1] === 'filmes' && partes[2]) {
    controller.remover(req, res, id);

  } else if (req.method === 'PUT' && partes[1] === 'filmes' && partes[2]) {
    controller.substituir(req, res, id);

  } else {
    res.writeHead(404);
    res.end(JSON.stringify({ erro: 'Rota não encontrada' }));
  }
}

module.exports = filmeRoutes;